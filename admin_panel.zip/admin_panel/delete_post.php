<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if the user is an admin
if (!isAdmin()) {
    redirect('dashboard.php');
}

// Check if the post ID is provided
if (!isset($_GET['post_id'])) {
    redirect('dashboard.php');
}

$post_id = $_GET['post_id'];

// Delete the post from the database
$query = "DELETE FROM wp_posts WHERE ID = '$post_id'";
$result = mysqli_query($conn, $query);

if ($result) {
    // Redirect back to the dashboard with a success message
    $_SESSION['success_message'] = "Post deleted successfully!";
    redirect('dashboard.php');
} else {
    // Redirect back to the dashboard with an error message
    $_SESSION['error_message'] = "Failed to delete the post.";
    redirect('dashboard.php');
}

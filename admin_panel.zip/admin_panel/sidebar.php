<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3>Menu</h3>
        <button id="toggle-sidebar">Toggle</button>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="index.php">Dashboard</a>
        </li>
        <li>
            <a href="add_post.php">Add Post</a>
        </li>
        <li>
            <a href="edit_post.php">Edit Post</a>
        </li>
        <li>
            <a href="users.php">Users</a>
        </li>
        <li>
            <a href="logout.php">Logout</a>
        </li>
    </ul>
</nav>

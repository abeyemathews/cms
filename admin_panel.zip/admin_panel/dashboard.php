<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Fetch all posts from the database
$query = "SELECT * FROM wp_posts ORDER BY post_date DESC";
$result = mysqli_query($conn, $query);

// Include header
include 'header.php';
?>

<main class="content">
    <div class="container">
        <h2>Dashboard</h2>
        <div class="mb-3">
            <a href="add_post.php" class="btn btn-primary">Add Post</a>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($post = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $post['post_title']; ?></td>
                        <td><?php echo $post['post_date']; ?></td>
                        <td>
                            <a href="edit_post.php?post_id=<?php echo $post['ID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="delete_post.php?post_id=<?php echo $post['ID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this post?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</main>

<?php
// Include footer
include 'footer.php';
?>

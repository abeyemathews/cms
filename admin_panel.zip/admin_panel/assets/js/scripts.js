// admin_panel/assets/js/scripts.js

// Code for any JavaScript functionality you want to add to your admin panel

// Example: Toggle sidebar visibility
document.getElementById('toggle-sidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('active');
});

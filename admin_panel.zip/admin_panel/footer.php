</main> <!-- Close the main content container -->

<footer>
    <p>&copy; <?php echo date('Y'); ?> Your Admin Panel. All rights reserved.</p>
</footer>

</body>
</html>

<?php
// admin_panel/logout.php

// Include necessary files
require_once 'includes/functions.php';

// Destroy the session
session_start();
session_destroy();

// Redirect to login page
redirect('login.php');
?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title']);
    $content = $_POST['content'];

    // Insert the post into the database
    $insertQuery = "INSERT INTO wp_posts (post_title, post_content) VALUES ('$title', '$content')";
    $result = mysqli_query($conn, $insertQuery);

    if ($result) {
        // Post added successfully, redirect back to dashboard
        redirect('dashboard.php');
    } else {
        $error_message = "Error adding the post.";
    }
}

// Include header
include 'header.php';
?>

<main class="content">
    <div class="container">
        <h2>Add Post</h2>
        <?php if (isset($error_message)) { ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php } ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Post</button>
        </form>
    </div>
</main>

<?php
// Include footer
include 'footer.php';
?>

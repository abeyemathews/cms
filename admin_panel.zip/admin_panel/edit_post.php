<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_id = $_POST['post_id'];
    $new_title = sanitizeInput($_POST['title']);
    $new_content = $_POST['content'];

    // Update the post in the database
    $updateQuery = "UPDATE wp_posts SET post_title = '$new_title', post_content = '$new_content' WHERE ID = $post_id";
    $result = mysqli_query($conn, $updateQuery);

    if ($result) {
        // Post updated successfully, redirect back to dashboard
        redirect('dashboard.php');
    } else {
        $error_message = "Error updating the post.";
    }
}

// Fetch post data from the database based on the provided post_id
if (isset($_GET['post_id'])) {
    $post_id = $_GET['post_id'];
    $query = "SELECT * FROM wp_posts WHERE ID = $post_id";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) === 1) {
        $post = mysqli_fetch_assoc($result);
    } else {
        $error_message = "Post not found.";
    }
}

// Include header
include 'header.php';
?>

<main class="content">
    <div class="container">
        <h2>Edit Post</h2>
        <?php if (isset($error_message)) { ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php } ?>
        <?php if (isset($post)) { ?>
            <form method="POST" action="">
                <input type="hidden" name="post_id" value="<?php echo $post['ID']; ?>">
                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" class="form-control" id="title" name="title" value="<?php echo $post['post_title']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="content" class="form-label">Content</label>
                    <textarea class="form-control" id="content" name="content" rows="5" required><?php echo $post['post_content']; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
        <?php } ?>
    </div>
</main>

<?php
// Include footer
include 'footer.php';
?>

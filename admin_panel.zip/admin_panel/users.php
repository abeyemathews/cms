<?php
// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if the user is an admin
if (!isAdmin()) {
    echo "You do not have permission to access this page.";
    exit();
}

// Include header
include 'header.php';
include 'sidebar.php';
?>

<main class="content">
    <h2>User Management</h2>
    
    <!-- Your user management content goes here -->
</main>

<?php
// Include footer
include 'footer.php';
?>

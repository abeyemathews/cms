<?php
// admin_panel/includes/functions.php

session_start();

// Redirect to a specified URL
function redirect($url) {
    header("Location: $url");
    exit();
}

// Check if a user is logged in
function isLoggedIn() {
    return isset($_SESSION["user_id"]);
}

// Check if a user is an admin
function isAdmin() {
    return isset($_SESSION["role"]) && $_SESSION["role"] === "admin";
}

// Secure input data
function secureInput($data) {
    // Implement your data validation and sanitization here
    return htmlspecialchars(trim($data));
}

// Hash passwords securely
function hashPassword($password) {
    // Implement a secure password hashing mechanism (e.g., password_hash())
    return password_hash($password, PASSWORD_DEFAULT);
}

// Verify hashed password
function verifyPassword($password, $hashedPassword) {
    return password_verify($password, $hashedPassword);
}

// Sanitize HTML output
function sanitizeOutput($output) {
    return htmlspecialchars($output, ENT_QUOTES, "UTF-8");
}

// Add your custom functions here
?>

<?php
// admin_panel/includes/db.php

// Database configuration
$host = "localhost";  // Your database host
$db_name = "test";  // Your database name
$db_user = "root";  // Your database username
$db_password = "";  // Your database password

// Create a database connection
$conn = new mysqli($host, $db_user, $db_password, $db_name);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
// admin_panel/includes/security.php

// Function to sanitize user input
function sanitizeInput($input) {
    if (is_array($input)) {
        foreach ($input as $key => $value) {
            $input[$key] = sanitizeInput($value);
        }
    } else {
        $input = htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    return $input;
}

// Function to escape data for safe use in SQL queries
function escapeData($data) {
    global $conn;
    return mysqli_real_escape_string($conn, $data);
}

// Function to generate a random token
function generateToken($length = 32) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $token = '';
    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $token;
}

// Function to validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate URL
function isValidURL($url) {
    return filter_var($url, FILTER_VALIDATE_URL);
}
?>

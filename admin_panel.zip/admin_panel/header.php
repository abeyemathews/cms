<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Admin Panel</title>
    <link rel="stylesheet" href="assets/css/styles.css">
<script src="assets/js/scripts.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


</head>
<body>
    <header>
        <h1>Your Admin Panel</h1>
    </header>
    <nav class="navbar">
        <a href="index.php">Dashboard</a>
        <a href="add_post.php">Add Post</a>
        <a href="edit_post.php">Edit Post</a>
        <a href="users.php">Users</a>
        <a href="logout.php">Logout</a>
    </nav>

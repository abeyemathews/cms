<?php
// admin_panel/index.php

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/security.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Check if the user is an admin
if (!isAdmin()) {
    echo "You do not have permission to access this page.";
    exit();
}

// Include header
include 'header.php';
?>

<!-- Main content goes here -->

<?php
// Include footer
include 'footer.php';
?>
